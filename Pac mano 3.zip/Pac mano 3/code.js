var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var pedrinho = createSprite(20,40,15,15);
    pedrinho.shapeColor = "blue";

var parede1 = createSprite(20,20,800,15);
    parede1.shapeColor = "red";

var parede2 = createSprite(20,60,150,15);
    parede2.shapeColor = "red";
    
var parede3 = createSprite(200,60,100,15);
    parede3.shapeColor = "red";
    
var paredebugada = createSprite(360,60,100,15);
    paredebugada.shapeColor = "gray";
    
var parede5 = createSprite(310,103,15,100);
    parede5.shapeColor = "red";
    
var parede6 = createSprite(310,150,15,100);
    parede6.shapeColor = "red";
    
var parede7 = createSprite(205,200,220,15);
    parede7.shapeColor = "red";
    
var parede8 = createSprite(158,110,15,100);
    parede8.shapeColor = "red";
    
var parede9 = createSprite(242,110,15,100);
    parede9.shapeColor = "red";
    
var parede10 = createSprite(87,110,15,100);
    parede10.shapeColor = "red";
    
var parede11 = createSprite(87,160,15,100);
    parede11.shapeColor = "red";
    
var cuboamarelo1 = createSprite(200,97,15,15);
    cuboamarelo1.shapeColor = "yellow";
    
var cuboamarelo2 = createSprite(40,97,15,15);
    cuboamarelo2.shapeColor = "yellow";
    
var jorge = createSprite(120,40,15,15);
    jorge.shapeColor = "green";
    
var primodojorge = createSprite(180,240,35,35);
    primodojorge.shapeColor = "green";
    
    jorge.velocityY = 10;
    
    primodojorge.velocityY = 7;
    
var pontos = 0;

function draw() {
  background("white");
  drawSprites();


  if (keyDown(RIGHT_ARROW)){
    pedrinho.velocityX = 2;
    pedrinho.velocityY = 0;
  }
  if (keyDown(LEFT_ARROW)){
    pedrinho.velocityX = -2;
    pedrinho.velocityY = 0;
  }
  if (keyDown(UP_ARROW)){
    pedrinho.velocityX = 0;
    pedrinho.velocityY = -2;
  }
  if (keyDown(DOWN_ARROW)){
    pedrinho.velocityX = 0;
    pedrinho.velocityY = 2;
  }
  
   createEdgeSprites();
   pedrinho.bounceOff(rightEdge);
   pedrinho.bounceOff(leftEdge);
   pedrinho.bounceOff(bottomEdge);
   pedrinho.bounceOff(topEdge);
   pedrinho.bounceOff(parede1);
   pedrinho.bounceOff(parede2);
   pedrinho.bounceOff(parede3);
   pedrinho.bounceOff(parede5);
   pedrinho.bounceOff(parede6);
   pedrinho.bounceOff(parede7);
   pedrinho.bounceOff(parede8);
   pedrinho.bounceOff(parede9);
   pedrinho.bounceOff(parede10);
   pedrinho.bounceOff(parede11);
   
   jorge.bounceOff(rightEdge);
   jorge.bounceOff(leftEdge);
   jorge.bounceOff(topEdge);
   jorge.bounceOff(parede1);
   jorge.bounceOff(parede2);
   jorge.bounceOff(parede3);
   jorge.bounceOff(paredebugada);
   jorge.bounceOff(parede5);
   jorge.bounceOff(parede6);
   jorge.bounceOff(parede7);
   jorge.bounceOff(parede8);
   jorge.bounceOff(parede10);
   jorge.bounceOff(parede11);
   
   primodojorge.bounceOff(edges);
   primodojorge.bounceOff(rightEdge);
   primodojorge.bounceOff(leftEdge);
   primodojorge.bounceOff(topEdge);
   primodojorge.bounceOff(parede1);
   primodojorge.bounceOff(parede2);
   primodojorge.bounceOff(parede3);
   primodojorge.bounceOff(paredebugada);
   primodojorge.bounceOff(parede5);
   primodojorge.bounceOff(parede6);
   primodojorge.bounceOff(parede7);
   primodojorge.bounceOff(parede8);
   primodojorge.bounceOff(parede10);
   primodojorge.bounceOff(parede11);
   
   if (pedrinho.isTouching(cuboamarelo1)){
    cuboamarelo1.destroy();
    pontos = pontos +1;
  }

  if (pedrinho.isTouching(cuboamarelo2)){
    cuboamarelo2.destroy();
    pontos = pontos +1;
  }
  
  
  if (pontos == 2){
    
    pedrinho.setVelocity(0,0);
    textSize(24);
    text("fim",100,200);
    text("agora que o jorge perdeu",100,250);
    text("pela 2 vez ele usara",100,300);
    text("sua arma secreta",100,350);
    
    parede1.destroy();
    parede2.destroy();
    parede3.destroy();
    paredebugada.destroy();
    parede5.destroy();
    parede6.destroy();
    parede7.destroy();
    parede8.destroy();
    parede9.destroy();
    parede10.destroy();
    parede11.destroy();
    pedrinho.destroy();
    jorge.destroy();
    cuboamarelo1.destroy();
    cuboamarelo2.destroy();
    primodojorge.destroy();
  }

  if (pedrinho.isTouching(jorge)){
   
   pedrinho.setVelocity(0,0);
   jorge.setVelocity(0,0);
   
   pedrinho.setVelocity(0,0);
   jorge.setVelocity(0,0);

   parede1.destroy();
   parede2.destroy();
   parede3.destroy();
   parede5.destroy();
   parede6.destroy();
   parede7.destroy();
   parede8.destroy();
   parede9.destroy();
   parede10.destroy();
   parede11.destroy();
   paredebugada.destroy();
   cuboamarelo1.destroy();
   cuboamarelo2.destroy();
   pedrinho.destroy();
   jorge.destroy();
   primodojorge.destroy();
 }
  
  if (pedrinho.isTouching(primodojorge)){
   
   pedrinho.setVelocity(0,0);
   jorge.setVelocity(0,0);
   
   pedrinho.setVelocity(0,0);
   jorge.setVelocity(0,0);

   parede1.destroy();
   parede2.destroy();
   parede3.destroy();
   parede5.destroy();
   parede6.destroy();
   parede7.destroy();
   parede8.destroy();
   parede9.destroy();
   parede10.destroy();
   parede11.destroy();
   paredebugada.destroy();
   cuboamarelo1.destroy();
   cuboamarelo2.destroy();
   pedrinho.destroy();
   jorge.destroy();
   primodojorge.destroy();
 }
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
